import math
from pathlib import Path

import torch
import torch.nn.functional as F

from spc import SPC
from fbdd_density import estimate_bandwidth, kde_log_posterior, packed_log_density


@torch.jit.script
def fuse_probabilities(prior: torch.Tensor, compatibility: torch.Tensor,
                       weight: float, logit_scale: float) -> torch.Tensor:
    return ((1.0 - weight) * prior + weight * compatibility).clamp_min(1e-30).log() / logit_scale


def debias(features, basis):
    x = F.normalize(features.float(), dim=1)
    flat = x.flatten(2).double()
    b = basis.to(device=x.device, dtype=torch.float64)
    flat = flat - b @ (b.T @ flat)
    return F.normalize(flat.float().reshape_as(x), dim=1)


def fit_reference(features, masks, basis):
    masks = masks.bool()
    if not masks.any() or masks.all() or not masks.flatten(1).any(1).all():
        return dict(valid=False)
    z = debias(features, basis).flatten(2).transpose(1, 2)
    labels = masks.flatten(1)
    fg, bg = z[labels], z[~labels]
    dim = z.shape[-1]
    a = fg - fg.mean(0)
    b = bg - bg.mean(0)
    cov = (a.T @ a + b.T @ b) / max(len(a) + len(b) - 2, 1)
    cov = .05 * cov + .95 * cov.diagonal().mean() * torch.eye(dim, device=z.device, dtype=z.dtype)
    values, vectors = torch.linalg.eigh(cov)
    transform = (vectors * values.clamp_min(1e-6).rsqrt()) @ vectors.T
    white = z @ transform
    fg = F.normalize(white[labels], dim=1)
    bg = F.normalize(white[~labels], dim=1)
    sigma, margin = estimate_bandwidth(fg, bg)
    return dict(valid=True, basis=basis, transform=transform, foreground=fg,
                background=bg, sigma=sigma, loo_margin=margin)


def fit_ragged(views, masks, basis):
    labels = [m.flatten().bool() for m in masks]
    if not all(m.any() for m in labels):
        return dict(valid=False)
    lab = torch.cat(labels)
    if lab.all():
        return dict(valid=False)
    zs = [debias(v[None], basis)[0].flatten(1).T for v in views]
    z = torch.cat(zs)
    fg, bg = z[lab], z[~lab]
    a = fg - fg.mean(0)
    b = bg - bg.mean(0)
    cov = (a.T @ a + b.T @ b) / max(len(a) + len(b) - 2, 1)
    cov = .05 * cov + .95 * cov.diagonal().mean() * torch.eye(z.shape[1], device=z.device)
    values, vectors = torch.linalg.eigh(cov)
    transform = (vectors * values.clamp_min(1e-6).rsqrt()) @ vectors.T
    white = [v @ transform for v in zs]
    all_white = torch.cat(white)
    fg = F.normalize(all_white[lab], dim=1)
    bg = F.normalize(all_white[~lab], dim=1)
    sigma, margin = estimate_bandwidth(fg, bg)
    return dict(valid=True, basis=basis, transform=transform, foreground=fg,
                background=bg, sigma=sigma, loo_margin=margin)


class FBDD(SPC):
    """Foreground–Background Distribution Discrimination following SPC."""

    def __init__(self, model, folds, checkpoint, fusion_weight=0.5):
        super().__init__(model, folds, checkpoint)
        self.fusion_weight = fusion_weight
        self.entries = [{}, {}]
        self.images = {}
        self.banks = [{}, {}]
        self._inference_banks = None

    def features(self, inputs):
        grid = super().features(inputs)
        self.grid = grid
        return grid

    @torch.no_grad()
    def collect(self, inputs, logits, path):
        super().collect(inputs, logits, path)
        fold = self.folds[Path(path).name]
        probabilities = (logits[0].float() * self.model.logit_scale).softmax(0)
        p = F.interpolate(probabilities[None], size=self.grid.shape[-2:], mode='bilinear', align_corners=False)[0].flatten(1)
        entropy = -(p * p.clamp_min(1e-30).log()).sum(0) / math.log2(self.model.num_classes)
        labels = p.argmax(0)
        for c in range(self.model.num_classes):
            indices = (labels == c).nonzero().flatten()
            if not len(indices):
                continue
            i = indices[entropy[indices].argmin()].item()
            entry = dict(image=str(path), entropy=entropy[i].item())
            bucket = self.entries[fold].setdefault(c, [])
            bucket.append(entry)
            bucket.sort(key=lambda x: x['entropy'])
            del bucket[3:]
        selected = {entry['image'] for fold_entries in self.entries
                    for bucket in fold_entries.values() for entry in bucket}
        if str(path) in selected:
            p = (logits.float() * self.model.logit_scale).softmax(1)
            labels = F.interpolate(p, size=self.grid.shape[-2:], mode='bilinear', align_corners=False)[0].argmax(0)
            self.images[str(path)] = dict(inputs=inputs.cpu().clone(),
                                          grid=self.grid[0].cpu().clone(), labels=labels.cpu())
        for old in list(self.images):
            if old not in selected:
                del self.images[old]

    @torch.no_grad()
    def freeze(self):
        super().freeze()
        device = self.model.device
        black = self.model.norm(torch.zeros(3, 336, 448, device=device))[None].half()
        z = F.normalize(self.net.get_intermediate_layers(black, n=1, reshape=True)[0].float(), dim=1)[0].flatten(1)
        z = z - z.mean(1, keepdim=True)
        basis = torch.linalg.svd(z.double(), full_matrices=False)[0][:, :250]
        flips = {path: self.features(image['inputs'].to(device).flip(-1))[0].cpu().clone()
                 for path, image in self.images.items()}
        for fold in (0, 1):
            for c in sorted(self.entries[fold]):
                paths = [entry['image'] for entry in self.entries[fold][c]]
                views = [self.images[path]['grid'].to(device) for path in paths]
                views += [flips[path].to(device) for path in paths]
                masks = [(self.images[path]['labels'] == c).to(device) for path in paths]
                masks += [mask.flip(-1) for mask in masks]
                if len({tuple(view.shape) for view in views}) == 1:
                    bank = fit_reference(torch.stack(views), torch.stack(masks), basis)
                else:
                    bank = fit_ragged(views, masks, basis)
                self.banks[fold][c] = {k: v.cpu() if torch.is_tensor(v) else v for k, v in bank.items()}
                print(f'Fit fold={fold} class={c} valid={bank["valid"]}', flush=True)
        self.images = {}

    def save(self, path, settings):
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        state = dict(settings=settings, folds=self.folds,
                     prototypes=self.prototypes.cpu(), present=self.present.cpu(),
                     banks=self.banks)
        temporary = path.with_suffix('.tmp')
        torch.save(state, temporary)
        temporary.replace(path)

    @torch.no_grad()
    def prepare_inference(self):
        """Keep all valid references on the model device for inference.

        The saved banks share a debiasing basis. Deduplicate it once on load,
        including older files that serialized a separate copy for each class.
        """
        device = torch.device(self.model.device)
        bases = []
        self._inference_banks = [{}, {}]
        grouped = [{}, {}]
        for fold, banks in enumerate(self.banks):
            for c, bank in banks.items():
                if not bank['valid']:
                    continue
                basis_id = next((i for i, basis in enumerate(bases)
                                 if torch.equal(basis, bank['basis'])), None)
                if basis_id is None:
                    basis_id = len(bases)
                    bases.append(bank['basis'])
                self._inference_banks[fold][c] = dict(basis_id=basis_id)
                grouped[fold].setdefault(basis_id, []).append((c, bank))
        self._inference_bases = [basis.to(device) for basis in bases]
        # Debiasing removes the basis directions. Express subsequent products
        # in its orthogonal complement without discarding any retained direction.
        self._inference_complements = [
            torch.linalg.qr(basis, mode='complete')[0][:, basis.shape[1]:].float()
            for basis in self._inference_bases]
        self._inference_complements = [F.pad(complement, (0, (-complement.shape[1]) % 8))
                                       for complement in self._inference_complements]
        self._inference_groups = [[], []]
        self._inference_classes = []
        for fold, groups in enumerate(grouped):
            classes = []
            for basis_id, entries in groups.items():
                # This tiles the GEMM workspace; every class and support vector
                # remains resident on the GPU and is evaluated for every image.
                for start in range(0, len(entries), 32):
                    batch = entries[start:start + 32]
                    complement = self._inference_complements[basis_id]
                    transforms = torch.stack([
                        complement.T @ bank['transform'].to(device) for _, bank in batch])
                    kernels, segments = [], []
                    offset = 0
                    for i, (c, bank) in enumerate(batch):
                        foreground = bank['foreground'].shape[0]
                        background = bank['background'].shape[0]
                        references = torch.cat([bank['foreground'], bank['background']]).to(device)
                        kernels.append(transforms[i] @ references.T)
                        segments.append((offset, offset + foreground,
                                         offset + foreground + background, bank['sigma']))
                        offset += foreground + background
                        classes.append(c)
                    kernels = torch.cat(kernels, dim=1)
                    # Align row strides for PyTorch 1.13's vectorized CUDA fuser.
                    # Padded columns are excluded by the saved segment offsets.
                    kernels = F.pad(kernels, (0, (-offset) % 4))
                    self._inference_groups[fold].append(dict(
                        basis_id=basis_id, transforms=transforms,
                        kernels=kernels, segments=segments))
            self._inference_classes.append(torch.tensor(classes, device=device, dtype=torch.long))

    @classmethod
    def load(cls, model, path, checkpoint, fusion_weight, settings):
        if not Path(path).is_file():
            raise FileNotFoundError(f'Support bank missing: {path}. Run bash build_bank.sh first.')
        state = torch.load(path, map_location='cpu')
        if state['settings'] != settings:
            raise ValueError(f'Support bank settings changed: {path}. Rebuild with bash build_bank.sh.')
        adapter = cls(model, state['folds'], checkpoint, fusion_weight)
        adapter.prototypes = state['prototypes'].to(model.device)
        adapter.present = state['present'].to(model.device)
        adapter.banks = state['banks']
        adapter.prepare_inference()
        return adapter

    @torch.no_grad()
    def refine(self, inputs, logits, path):
        core = super().refine(inputs, logits, path)
        if self._inference_banks is None:
            self.prepare_inference()
        fold = 1 - self.folds[Path(path).name]
        banks = self._inference_banks[fold]
        if len(banks) < 2:
            return core
        prior = (core.float() * self.model.logit_scale).softmax(1)
        compat = prior.clone()
        projected = {}
        posteriors = []
        for group in self._inference_groups[fold]:
            basis_id = group['basis_id']
            if basis_id not in projected:
                z = debias(self.grid, self._inference_bases[basis_id])[0].flatten(1).T
                projected[basis_id] = z @ self._inference_complements[basis_id]
            z = projected[basis_id]
            norms = (z[None] @ group['transforms']).norm(dim=-1).clamp_min(1e-12)
            similarities = z @ group['kernels']
            for i, (start, middle, stop, sigma) in enumerate(group['segments']):
                fg = packed_log_density(similarities[:, start:middle], norms[i], sigma, middle - start)
                bg = packed_log_density(similarities[:, middle:stop], norms[i], sigma, stop - middle)
                posteriors.append(fg - bg)
        posterior = torch.stack(posteriors).reshape(1, len(banks), *self.grid.shape[-2:])
        posterior = F.interpolate(posterior, size=core.shape[-2:], mode='bilinear', align_corners=False)
        compat[0, self._inference_classes[fold]] = posterior[0].sigmoid()
        return fuse_probabilities(prior, compat, float(self.fusion_weight), float(self.model.logit_scale))
