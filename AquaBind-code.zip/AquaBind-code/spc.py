import hashlib
import json
from pathlib import Path
from PIL import Image
from tqdm import tqdm
from dinov2.vision_transformer import vit_base

import torch
import torch.nn.functional as F


def pixel_weights(confidence, labels, counts, num_classes):
    threshold = 2.0 / num_classes
    eligible = (confidence > threshold) & (counts[labels] >= 5)
    excess = ((confidence.float() - threshold) / max(1.0 - threshold, 1e-6)).clamp(0.0, 1.0)
    return torch.where(eligible, excess, torch.zeros_like(excess))


def transform_features(features):
    return features.float()


def image_contribution(sums, masses):
    s = sums.float()
    m = masses.float().clamp_min(0)
    active = m > 0
    divisor = (m + 5.0).sqrt()
    balanced_sums = torch.where(
        active[:, None], s / divisor[:, None], torch.zeros_like(s)
    )
    balanced_masses = torch.where(active, m / divisor, torch.zeros_like(m))
    return balanced_sums, balanced_masses


def finalize_prototypes(sums, masses):
    active = masses > 0
    masked_sums = torch.where(active[:, None], sums.float(), torch.zeros_like(sums.float()))
    return F.normalize(masked_sums, dim=-1)


def correction(features, prototypes, present, probabilities, gain=2.5, suppression=0.5):
    p = prototypes.float()
    active = present.bool()
    if active.sum() < 2:
        return p.new_zeros((p.shape[0], features.shape[1]))
    p = torch.where(active[:, None], p, torch.zeros_like(p))
    q = F.normalize(features.float(), dim=0)
    shared = F.normalize(p[active].mean(dim=0), dim=0)
    p_residual = p - suppression * (p @ shared)[:, None] * shared[None, :]
    q_residual = q - suppression * shared[:, None] * (shared @ q)[None, :]
    scores = F.normalize(p_residual, dim=1) @ F.normalize(q_residual, dim=0)
    centered = scores - scores[active].mean(dim=0, keepdim=True)
    return torch.where(active[:, None], gain * centered, torch.zeros_like(centered))


def correction_grids(features, prototypes, present, gain=2.5, suppression=0.5):
    """Project classes before interpolation; normalize at each output pixel.

    Shared-direction removal and class projection are linear, so both commute
    with bilinear sampling. The two feature normalizations in ``correction``
    cancel, leaving the norm of the interpolated residual in the denominator.
    """
    p = prototypes.float()
    active = present.bool()
    p = torch.where(active[:, None], p, torch.zeros_like(p))
    shared = F.normalize(p[active].mean(dim=0), dim=0)
    p_residual = F.normalize(
        p - suppression * (p @ shared)[:, None] * shared[None, :], dim=1)
    raw = features.float().flatten(2)[0]
    residual = raw - suppression * shared[:, None] * (shared @ raw)[None, :]
    scores = p_residual @ residual
    centered = scores - scores[active].mean(dim=0, keepdim=True)
    scores = torch.where(active[:, None], gain * centered, torch.zeros_like(centered))
    return residual.reshape_as(features), scores.reshape(1, p.shape[0], *features.shape[-2:])


@torch.jit.script
def add_correction(logits: torch.Tensor, numerator: torch.Tensor,
                   norms: torch.Tensor, logit_scale: float) -> torch.Tensor:
    return logits + (numerator / norms) / logit_scale


def build_folds(dataset, entries, fold_path):
    names = [Path(entry['img_path']).name for entry in entries]
    if len(set(names)) != len(names):
        raise ValueError('SPC requires unique image filenames')
    with open(fold_path, 'r', encoding='utf-8') as f:
        saved_folds = json.load(f).get(dataset, {})
    if saved_folds and all(name in saved_folds for name in names):
        folds = {name: saved_folds[name] for name in names}
    else:
        groups = {}
        for entry in tqdm(entries, desc='Grouping images'):
            path = Path(entry['img_path'])
            with Image.open(path) as image:
                rgb = image.convert('RGB')
                digest = hashlib.sha256(str(rgb.size).encode() + rgb.tobytes()).hexdigest()
            groups.setdefault(digest, []).append(path.name)
        folds = {}
        for group in groups.values():
            fold = int(hashlib.sha256(min(group).encode()).hexdigest(), 16) % 2
            folds.update({name: fold for name in group})
    if set(folds.values()) != {0, 1}:
        raise ValueError('SPC requires two nonempty support folds')
    return folds


def dense_chunks(features, size, chunk=32):
    h, w = size
    xs = (torch.arange(w, device=features.device, dtype=torch.float32) + .5) * 2 / w - 1
    for start in range(0, h, chunk):
        stop = min(h, start + chunk)
        ys = (torch.arange(start, stop, device=features.device, dtype=torch.float32) + .5) * 2 / h - 1
        yy, xx = torch.meshgrid(ys, xs, indexing='ij')
        grid = torch.stack([xx, yy], -1)[None]
        out = F.grid_sample(features.float(), grid, mode='bilinear', padding_mode='border', align_corners=False)
        yield start, stop, out[0].flatten(1)


class SPC:
    """Shared-Direction-Suppressed Prototype Calibration."""

    def __init__(self, model, folds, checkpoint):
        self.gain = 2.5
        self.suppression = 0.5
        if model.num_classes != model.num_queries:
            raise ValueError('SPC requires one query per class')
        net = vit_base(patch_size=14, img_size=518, init_values=1., block_chunks=0, num_register_tokens=0)
        net.load_state_dict(torch.load(checkpoint, map_location='cpu'), strict=True)
        self.net = net.eval().to(model.device).half()
        for p in self.net.parameters():
            p.requires_grad_(False)
        self.model = model
        self.folds = folds
        self.sums = torch.zeros(2, model.num_classes, 768, device=model.device, dtype=torch.float64)
        self.masses = torch.zeros(2, model.num_classes, device=model.device, dtype=torch.float64)

    @torch.no_grad()
    def features(self, inputs):
        h, w = inputs.shape[-2:]
        dh = max(14, round(h * 336 / min(h, w) / 14) * 14)
        dw = max(14, round(w * 336 / min(h, w) / 14) * 14)
        image = F.interpolate(inputs, size=(dh, dw), mode='bilinear', align_corners=False)
        image = torch.stack([self.model.norm(self.model.unnorm(im)) for im in image]).half()
        features = self.net.forward_features(image)['x_norm_patchtokens']
        return features.transpose(1, 2).reshape(1, 768, dh // 14, dw // 14)

    @torch.no_grad()
    def collect(self, inputs, logits, path):
        fold = self.folds[Path(path).name]
        c = logits.shape[1]
        probabilities = (logits[0].float() * self.model.logit_scale).softmax(0)
        confidence, labels = probabilities.max(0)
        counts = torch.bincount(labels[confidence > 2 / c], minlength=c)
        weights = pixel_weights(confidence.flatten(), labels.flatten(), counts, c).reshape(labels.shape)
        features = self.features(inputs)
        sums = torch.zeros_like(self.sums[fold])
        mass = torch.zeros_like(self.masses[fold])
        for start, stop, raw in dense_chunks(features, logits.shape[-2:]):
            values = transform_features(raw)
            lab = labels[start:stop].flatten()
            w = weights[start:stop].flatten().double()
            active_classes = torch.unique(lab[w > 0], sorted=True).tolist()
            for k in active_classes:
                mask = (lab == k) & (w > 0)
                sums[k] += (values[:, mask].double() * w[mask]).sum(-1)
                mass[k] += w[mask].sum()
        sums, mass = image_contribution(sums, mass)
        self.sums[fold] += sums
        self.masses[fold] += mass

    def freeze(self):
        self.prototypes = torch.stack([finalize_prototypes(sums, masses)
                                       for sums, masses in zip(self.sums, self.masses)])
        self.present = self.masses > 0

    @torch.no_grad()
    def refine(self, inputs, logits, path):
        bank = 1 - self.folds[Path(path).name]
        present = self.present[bank]
        features = self.features(inputs)
        result = logits.clone()
        if present.sum() < 2:
            return result
        residual, score_grid = correction_grids(
            features, self.prototypes[bank], present, self.gain, self.suppression)
        for (start, stop, raw), (_, _, numerator) in zip(
                dense_chunks(residual, logits.shape[-2:], chunk=128),
                dense_chunks(score_grid, logits.shape[-2:], chunk=128)):
            norms = raw.norm(dim=0, keepdim=True).clamp_min(1e-24)
            region = result[0, :, start:stop]
            result[0, :, start:stop] = add_correction(
                region, numerator.reshape_as(region),
                norms.reshape(1, stop - start, logits.shape[-1]), float(self.model.logit_scale))
        return result
