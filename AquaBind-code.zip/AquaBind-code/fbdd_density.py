# Density estimation for Foreground–Background Distribution Discrimination (FBDD).
# Licensed under the Apache License 2.0.
# License text: dinov2/LICENSE.
from __future__ import annotations

import math
from typing import Tuple

import torch


@torch.jit.script
def _packed_log_density(similarities: torch.Tensor, norms: torch.Tensor,
                        sigma: float, log_count: float) -> torch.Tensor:
    # Cosine similarities lie in [-1, 1]. For the fitted bandwidths (>= .05),
    # exponents lie in [-40, 0], safely inside the FP32 range. The direct
    # reduction lets TorchScript fuse scaling, exp, sum and log into a kernel.
    values = (similarities / norms[:, None] - 1.0) / sigma
    return values.exp().sum(-1).log() - log_count


def packed_log_density(similarities, norms, sigma, count):
    """Density from pretransformed references, retaining every support vector."""
    sigma = max(float(sigma), 1e-6)
    log_count = math.log(max(count, 1))
    if sigma >= .05 and similarities.dtype in (torch.float32, torch.float64):
        return _packed_log_density(similarities, norms, sigma, log_count)
    # Retain stable logsumexp for externally supplied narrower bandwidths.
    values = (similarities / norms[:, None] - 1.0) / sigma
    return values.logsumexp(-1) - log_count


@torch.no_grad()
def _chunked_lse_sim(A: torch.Tensor, B: torch.Tensor, sigma: float,
                     log_count, self_diag: bool = False) -> torch.Tensor:
    """Memory-safe ``logsumexp((A @ B.T - 1)/sigma, dim=1) - log_count``.

    Splits A's ROWS so the (rows x anchors) block stays within a fixed element
    budget; logsumexp reduces over the full anchor dim per chunk, so the result
    is bit-identical to the un-chunked form. ``self_diag=True`` masks each row's
    own column (leave-one-out self-exclusion), needed for the LOO bandwidth and
    for high-shot anchor pools that would otherwise OOM at once.
    """
    Nt = A.shape[0]
    Nc = max(B.shape[0], 1)
    s = max(sigma, 1e-6)
    budget = 150_000_000  # ~600 MB fp32 per block
    chunk = max(64, min(Nt, int(budget // Nc)))
    if chunk >= Nt and not self_diag:
        sim = (A @ B.T - 1.0) / s
        return torch.logsumexp(sim, dim=1) - log_count
    parts = []
    for i in range(0, Nt, chunk):
        blk = (A[i:i + chunk] @ B.T - 1.0) / s
        if self_diag:
            r = blk.shape[0]
            idx = torch.arange(r, device=blk.device)
            blk[idx, i + idx] = float("-inf")
        parts.append(torch.logsumexp(blk, dim=1))
    return torch.cat(parts, 0) - log_count


@torch.no_grad()
def kde_log_posterior(
    feat_tgt: torch.Tensor,   # (N_t, D), L2-normalized
    feat_fg: torch.Tensor,    # (N_fg, D), L2-normalized
    feat_bg: torch.Tensor,    # (N_bg, D), L2-normalized
    sigma: float,
) -> torch.Tensor:
    """Per-patch log-posterior ratio l(t) = log p(t|FG) - log p(t|BG). Returns (N_t,)."""
    log_p_fg = _chunked_lse_sim(feat_tgt, feat_fg, sigma, math.log(max(feat_fg.shape[0], 1)))
    log_p_bg = _chunked_lse_sim(feat_tgt, feat_bg, sigma, math.log(max(feat_bg.shape[0], 1)))
    return log_p_fg - log_p_bg


@torch.no_grad()
def loo_margin_score(feat_fg: torch.Tensor, feat_bg: torch.Tensor, sigma: float) -> float:
    """Leave-one-out margin E[l(f_FG)] - E[l(f_BG)] on support. Higher = better sigma."""
    if feat_fg.shape[0] < 2 or feat_bg.shape[0] < 2:
        return 0.0
    # LLR on FG support (leave self out) -- should be > 0
    log_p_fg_loo = _chunked_lse_sim(feat_fg, feat_fg, sigma,
                                    math.log(feat_fg.shape[0] - 1), self_diag=True)
    log_p_bg_at_fg = _chunked_lse_sim(feat_fg, feat_bg, sigma, math.log(feat_bg.shape[0]))
    llr_fg = log_p_fg_loo - log_p_bg_at_fg
    # LLR on BG support (leave self out) -- should be < 0
    log_p_bg_loo = _chunked_lse_sim(feat_bg, feat_bg, sigma,
                                    math.log(feat_bg.shape[0] - 1), self_diag=True)
    log_p_fg_at_bg = _chunked_lse_sim(feat_bg, feat_fg, sigma, math.log(feat_fg.shape[0]))
    llr_bg = log_p_fg_at_bg - log_p_bg_loo
    return float(llr_fg.mean().item()) - float(llr_bg.mean().item())


@torch.no_grad()
def estimate_bandwidth(
    feat_fg: torch.Tensor,
    feat_bg: torch.Tensor,
    sigma_grid: tuple = (0.05, 0.10, 0.20, 0.50, 1.00),
) -> Tuple[float, float]:
    """Pick sigma from the grid that maximizes the LOO support margin."""
    best_sigma, best_score = sigma_grid[0], -float("inf")
    for s in sigma_grid:
        sc = loo_margin_score(feat_fg, feat_bg, s)
        if sc > best_score:
            best_score = sc
            best_sigma = s
    return best_sigma, best_score
