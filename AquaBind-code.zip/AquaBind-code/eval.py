import os
import argparse
from fbdd import FBDD
import AquaBind
import custom_datasets
from myutils import append_experiment_result
from mmengine.config import Config
from mmengine.runner import Runner

def parse_args():
    parser = argparse.ArgumentParser(
        description='Segmentation evaluation')
    parser.add_argument('--config', default='./configs/cfg_coco_stuff164k.py')
    parser.add_argument('--work-dir', default='./work_logs/')
    parser.add_argument('--model_type', default='ViT-B/16')
    parser.add_argument('--beta', type=float, default=1.2)
    parser.add_argument('--gamma', type=float, default=3.0)
    parser.add_argument('--vfm_model', default='geometric')
    parser.add_argument('--geofeats_idx', default='3')
    parser.add_argument('--similarity_threshold', type=float, default=0.5)
    parser.add_argument('--max_weight', type=float, default=0.5)
    parser.add_argument('--use_uwtemplate', action="store_true")
    parser.add_argument('--use_mllm', action="store_true")
    parser.add_argument('--mllm_type', default='4o')
    
    parser.add_argument('--show', action='store_true', help='show prediction results')
    parser.add_argument('--show_dir',default='./show_dir/', help='directory to save visualizaion images')

    parser.add_argument('--launcher', choices=['none', 'pytorch', 'slurm', 'mpi'], default='none', help='job launcher')
    # When using PyTorch version >= 2.0.0, the `torch.distributed.launch`
    # will pass the `--local-rank` parameter to `tools/train.py` instead
    # of `--local_rank`.
    parser.add_argument('--local_rank', '--local-rank', type=int, default=0)
    args = parser.parse_args()
    if 'LOCAL_RANK' not in os.environ:
        os.environ['LOCAL_RANK'] = str(args.local_rank)

    return args

def get_runner():
    args = parse_args()

    cfg = Config.fromfile(args.config)
    if os.environ.get('SUPPORT_BANK_DIR'):
        cfg.spc.bank_dir = os.environ['SUPPORT_BANK_DIR']
    cfg.launcher = args.launcher
    cfg.work_dir = args.work_dir
    cfg.model.model_type = args.model_type

    cfg.model.beta=args.beta
    cfg.model.gamma=args.gamma
    cfg.model.vfm_model=args.vfm_model
    cfg.model.geofeats_idx=args.geofeats_idx
    cfg.model.similarity_threshold=args.similarity_threshold
    cfg.model.max_weight=args.max_weight
    cfg.model.use_uwtemplate=args.use_uwtemplate
    cfg.model.use_mllm=args.use_mllm
    cfg.model.mllm_type=args.mllm_type

    cfg.model.show=args.show
    cfg.model.show_dir=args.show_dir

    if args.model_type == 'ViT-B/16':
        cfg.model.clip_type = 'pretrained_ckpt/vitb.bin'
    elif args.model_type == 'ViT-L-14':
        cfg.model.clip_type = 'pretrained_ckpt/vitl.bin'
    elif args.model_type == 'ViT-H-14':
        cfg.model.clip_type = 'pretrained_ckpt/vith.bin'

    runner = Runner.from_cfg(cfg)
    return cfg, runner

def get_bank_path(cfg):
    model_type = cfg.model.model_type.replace('/', '_')
    filename = f'{cfg.dataset_type}_{model_type}_{cfg.model.mllm_type}.pth'
    return os.path.join(cfg.spc.bank_dir, filename)

def get_bank_settings(cfg, entries):
    return dict(
        model={k: v for k, v in cfg.model.to_dict().items() if k not in ('show', 'show_dir')},
        checkpoint=cfg.spc.checkpoint,
        fold_path=cfg.spc.fold_path,
        fusion_weight=cfg.fbdd.fusion_weight,
        pipeline=cfg.to_dict()['test_pipeline'],
        images=[os.path.basename(entry['img_path']) for entry in entries])

def main():
    cfg, runner = get_runner()
    model = runner.model.eval()
    dataset = runner.test_dataloader.dataset
    entries = [dataset.get_data_info(i) for i in range(len(dataset))]
    bank_path = get_bank_path(cfg)
    model.fbdd = FBDD.load(model, bank_path, cfg.spc.checkpoint,
                           cfg.fbdd.fusion_weight, get_bank_settings(cfg, entries))
    print(f'Loaded banks: {bank_path}', flush=True)
    results = runner.test()

    results.update({'Model': cfg.model.model_type,
                    'CLIP': cfg.model.clip_type,
                    'VFM': cfg.model.vfm_model,
                    'Dataset': cfg.dataset_type})

    if runner.rank == 0:
        append_experiment_result(os.environ.get('RESULTS_XLSX', 'results.xlsx'), [results])

    if runner.rank == 0:
        with open(os.path.join(cfg.work_dir, 'results.txt'), 'a') as f:
            f.write(os.path.basename(cfg.filename).split('.')[0] + '\n')
            for k, v in results.items():
                f.write(k + ': ' + str(v) + '\n')

if __name__ == '__main__':
    main()
