import os
import torch
from tqdm import tqdm
from eval import get_runner, get_bank_path, get_bank_settings
from spc import build_folds
from fbdd import FBDD


def main():
    cfg, runner = get_runner()
    model = runner.model.eval()
    dataset = runner.test_dataloader.dataset
    entries = [dataset.get_data_info(i) for i in range(len(dataset))]
    dataset_name = os.path.basename(cfg.filename).replace('cfg_', '').replace('.py', '')
    folds = build_folds(dataset_name, entries, cfg.spc.fold_path)
    fbdd = FBDD(model, folds, cfg.spc.checkpoint, cfg.fbdd.fusion_weight)
    with torch.inference_mode():
        for batch in tqdm(runner.test_dataloader, desc='Building banks'):
            packed = model.data_preprocessor(batch, training=False)
            inputs = packed['inputs']
            meta = packed['data_samples'][0].metainfo
            logits = model.forward_slide(inputs, meta['img_path'], [meta], model.slide_stride, model.slide_crop)
            fbdd.collect(inputs, logits, meta['img_path'])
            del logits, packed, inputs
    fbdd.freeze()
    bank_path = get_bank_path(cfg)
    fbdd.save(bank_path, get_bank_settings(cfg, entries))
    print(f'Saved banks: {bank_path}', flush=True)


if __name__ == '__main__':
    main()
