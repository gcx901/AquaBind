# base configurations
use_uwtemplate=False
use_mllm=False
mllm_type="qwen"
model = dict(
    type='AquaBindSegmentation',
    clip_type='pretrained_ckpt/vitl.bin',
    model_type='ViT-L-14',
    checkpoint=None,
    # Geometric-guided Visual Mask Generator
    beta=1.2, 
    gamma=3.0, 
    vfm_model='geometric',
    geofeats_idx='3',
    # Category-visual Semantic Alignment
    # Dual-Anchor Semantic Association (DASA)
    description_path='configs/full_class_descriptions.json',
    similarity_threshold=0.5,
    max_weight=0.5,
    use_uwtemplate=use_uwtemplate,
    use_mllm=use_mllm,
    mllm_type=mllm_type
)

# ('pretrained_ckpt/vitb.bin', 'ViT-B/16')
# ('pretrained_ckpt/vitl.bin', 'ViT-L-14')
# ('pretrained_ckpt/vith.bin', 'ViT-H-14')

# Shared-Direction-Suppressed Prototype Calibration (SPC)
spc = dict(
    checkpoint='pretrained_ckpt/dinov2_vitb14_pretrain.pth',
    fold_path='configs/spc_folds.json',
    bank_dir='pretrained_ckpt/support_banks'
)

# Foreground–Background Distribution Discrimination (FBDD)
fbdd = dict(fusion_weight=0.5)

test_evaluator = dict(type='IoUMetric', iou_metrics=['mIoU'])

default_scope = 'mmseg'
env_cfg = dict(
    cudnn_benchmark=True,
    mp_cfg=dict(mp_start_method='fork', opencv_num_threads=0),
    dist_cfg=dict(backend='nccl'),
)
vis_backends = [dict(type='LocalVisBackend')]
visualizer = dict(
    type='SegLocalVisualizer', vis_backends=vis_backends, alpha=1.0, name='visualizer')
log_processor = dict(by_epoch=False)
log_level = 'INFO'
load_from = None
resume = False

test_cfg = dict(type='TestLoop')

default_hooks = dict(
    timer=dict(type='IterTimerHook'),
    logger=dict(type='LoggerHook', interval=50, log_metric_by_epoch=False),
    param_scheduler=dict(type='ParamSchedulerHook'),
    checkpoint=dict(type='CheckpointHook', by_epoch=False, interval=2000),
    sampler_seed=dict(type='DistSamplerSeedHook'),
    visualization=dict(type='SegVisualizationHook', interval=5))
