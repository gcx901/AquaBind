_base_ = './base_config.py'

# model settings
model = dict(
    name_path='configs/cls_dutuseg.txt',
    json_path='configs/llm_reasoning_dutuseg.json',
    imgname_list_path='configs/imglist_dutuseg.txt'
)

# dataset settings
dataset_type = 'DUTUSEGDataset'
data_root = 'datasets/DUT-USEG'

test_pipeline = [
    dict(type='LoadImageFromFile'),
    dict(type='Resize', scale=(2048, 336), keep_ratio=True),
    dict(type='LoadAnnotations'),
    dict(type='PackSegInputs')
]

test_dataloader = dict(
    batch_size=1,
    num_workers=4,
    persistent_workers=True,
    sampler=dict(type='DefaultSampler', shuffle=False),
    dataset=dict(
        type=dataset_type,
        data_root=data_root,
        data_prefix=dict(
            img_path='img', seg_map_path='mask'),
        pipeline=test_pipeline))